console.log("working")

window.setInterval(replaceimages, 2000);

replaceimages();

function replaceimages() {
  $(document).ready(function() {
      $('img').attr('src','http://68.183.51.115/colorgif.gif')
      console.log("replacing")
  });
}

function redirect(){
  for (var i = 0; i < links.length; i++) {

    window.open(links[i]);

    console.log("counting");
  }
}
