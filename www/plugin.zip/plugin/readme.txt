

install instructions for chrome only//

~~~~~~~~~~~~~~~~~~~~~~~~

1. unzip plugin.js

2. chrome://extensions

3. load unpacked (select the folder "plugin")

                (make sure developer mode is enabled in top right)

~~~~~~~~~~~~~~~~~~~~~~~~
